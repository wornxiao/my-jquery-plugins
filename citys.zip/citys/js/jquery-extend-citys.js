function checkselec(){
	   $("#areainput").val("");
		$("#chooseCity").html("");
		var checkboxs=$("input[type='checkbox']");
		var valuestr="";
		var showstr="";
		checkboxs.each(function(){
			var ched=$(this).attr('checked');
			if(ched=='checked'){
				var cls=$(this).attr("class");
				var index=cls.indexOf('cit');
				if(index!=-1){//�������
					var provinName=$(this).parent().attr("id");
					var cityName=$(this).val();
					var cisys=provinName+"_"+cityName+","; 
					valuestr=valuestr+cisys;

					var province=provinName.split("_")[1];
					var city=cityName.split("_")[1];
					var pcname=province+city;
					showstr=showstr+pcname+",";
				}else{//ʡ��
					var id=$(this).val();
					valuestr=valuestr+id+",";
					var val=id.split("_")[1];
					showstr=showstr+val+",";
				}
			}
		});	
		valuestr=valuestr.substring(0,valuestr.length-1);
		showstr=showstr.substring(0,showstr.length-1);
		$("#areainput").val(valuestr);
		$("#chooseCity").append($("<span>"+showstr+"</span>"));
}

;(function($,window,document,undefined){
	//��չһ���������
	var City=function(ele,opt){
	this.$element=ele;
	this.defaults = {
		'citys':'',
        'checkcity':'',
		'checkIds':'',
		'color': 'red',
        'fontSize': '12px',
        'textDecoration':'none'
    },
    this.options = $.extend({}, this.defaults, opt)
		
	}

	//����Beautifier�ķ���
	City.prototype = {
		init:function(){
			//��ʼ������
			var citys=this.options.citys;
		    var jsonObj =  JSON.parse(citys)
			var ele=this;
			var provinces=$("<div id='provinces'></div>");
			provinces.addClass("provic");
			for(var i in jsonObj){
				var pid=jsonObj[i].pid;
				var province=jsonObj[i].pname;
				var div=$("<div id='"+pid+"' class='divpro' ><input id='"+pid+"' name='"+pid+"' type='checkbox' class='pro' value='"+pid+"_"+province+"'>"+province+"</input></div>")//ʡ
				var citysObj=jsonObj[i].regionList;

				var citys=$("<div id='"+pid+"_"+province+"'></div>");//��
				citys.addClass("cityc");
				for(var j in citysObj ){
					var city=$("<input id='"+citysObj[j].rid+"'     class='cit' type='checkbox' value='"+citysObj[j].rid+"_"+citysObj[j].rname+"'>"+citysObj[j].rname+"</input>")
					if(j%3==0) citys.append($("<br>"))
					citys.append(city);
				}
				div.append(citys);
				citys.hide();
				provinces.append(div);
				if(i%8==0){
					provinces.append("</br>");
				}
				citys.bind('mouseover',ele.cfocusShow);
				citys.bind('mouseout',ele.cunfocusShow);
			}	
			
			//��ʼ��ѡ��״̬
			var checkcity=this.options.checkcity;
		    var ctts=checkcity.split(",");
			var patt = /[0-9]+_[\u4E00-\u9FA5]+_[0-9]+_[\u4E00-\u9FA5]/;
			var ids=new Array();
			for(var i in ctts){
				var istrue=patt.test(ctts[i]);
				if(istrue){//��
					var ss=ctts[i].lastIndexOf("_");
					var end=ctts[i].substring(0,ss);
					var start=end.lastIndexOf("_");
					var ssdx=ctts[i].substring(start+1,ctts[i].length);
					var stsv=ssdx.split("_")[0];
					ids.push(stsv);
				}else{//ʡ
					var cs=ctts[i].split("_")[0];
					ids.push(cs);
				}
			}
			var idString=ids.join(",");
			//��ʼ����ʱ�� �ٸ�һ������
			var area=$("<div id='area'><lable>��ѡ����</lable>:<div id='chooseCity'></div><input id='areainput' name='areainput'  type='hidden'></input></div>")
			
			$("#div").append(area);
			$("#div").append(provinces);
			var divpro=$(".divpro");
            divpro.each(function(){
				$(this).bind('mouseout',ele.mouseouts);
            });

			var checkboxs=$(".pro");//ʡ��������¼�
			checkboxs.each(function(){
				$(this).bind('mouseover',ele.unfocusShow);
				$(this).bind('change',ele.focusShow);
            });

			var ccboxs=$(".cit");
			ccboxs.each(function(){
				$(this).bind('change',ele.focusShow);
            });
		    this.initchecked(idString);
			return this;
		},
        focusShow:function(){
			var checked=$(this).attr('checked');
			var val=$(this).val();
			if(checked=='checked'){
				$('#'+val).show();
				window.checkselec();
			}else{
				$('#'+val).hide();
				//���ռ�֮ǰ�����ʡ�Ļ� ȡ�����������еĵ��е�ѡ��
				var cls=$(this).attr("class");
				var index=cls.indexOf('cit');
				if(index==-1){
					var idpro=$(this).val();
					var ccs=$("#"+idpro).children("[type='checkbox']");	
					ccs.each(function(){
						$(this).removeAttr("checked");
					});
				}
				window.checkselec();
			}
			return this;
        },
		unfocusShow:function(){
			var checked=$(this).attr('checked');
			var val=$(this).val();
			if(checked=='checked'){
				$('#'+val).show();
			}else{
				$('#'+val).hide();
			}
			return this;
        },
        cfocusShow:function(){
			$(this).show();
			return this;
        },
		cunfocusShow:function(){
			$(this).hide();
			return this;
		},
		mouseouts:function(){
			var val=$(this).val();
			$('#'+val).hide();
			return this;
		},
		initchecked:function(obj){
			//��ʼ��ѡ��ʱ��
			var checks=$("input[type='checkbox']");
			checks.each(function(){
			var id=$(this).attr("id");
            if(obj.indexOf(id)!=-1){
				$(this).attr("checked","checked");
				$(this).trigger('change');
            }
			var cits=$(".cityc");
			cits.each(function(){
				$(this).hide();
			});
			return this;
		});
		}
	}
	//�ڲ����ʹ��Beautifier����
	$.fn.xiao_wen = function(options) {
		//����Beautifier��ʵ��
		var city = new City(this, options);
		//�����䷽��
		return city.init();
	}
})(jQuery,window,document);//ͨ���Ե��������������������ֹ ��Ⱦȫ�ֱ���,�������������ڵ�һʱ��ִ��




